export default {
  testEnvironment: "node"
}
