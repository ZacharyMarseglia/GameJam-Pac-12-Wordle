export default {
  testEnvironment: "node"
}
